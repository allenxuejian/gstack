# test-skill · 完整契约清单

> **Kevin 环境专属 CRITICAL**（MongoDB 测试隔离 / Opus subagent / 失败升级）统一在 `~/.claude/skills/_shared/kevin-personal-constraints.md`。本文只列通用测试规则 + skill 特有 CRITICAL。
> 分享给别人时删掉 `_shared/` 引用即可。

每条契约带 **Why**（原因）+ **How to apply**（怎么用），方便遇到边界情况判断。

---

## 产品契约

### MUST

- **MUST 三类路径覆盖：happy / edge / error。**
  - Why: 只测 happy 等于没测安全边界。bug 大多出在 edge 和 error 上。
  - How: 每个被测函数至少 3 个测试：正常输入（happy）、边界值/空/最大（edge）、错误输入/异常路径（error）。

- **MUST 新测试必须故意破坏源代码跑一次确认能红。**
  - Why: CLAUDE.md 全局"完成必验证"扩展到测试：测试真能抓 bug 才叫测试。
  - How: 写完测试 → 在源码里 invert 一个条件（`> ` 改 `< `）→ `bun test` → 必须红。红了再改回来。

- **MUST 相似用例用参数化。**
  - Why: 维护成本。复制 5 遍改一处要改 5 次。
  - How: `it.each([[1, 2, 3], [5, 5, 10]])('%d + %d = %d', (a, b, expected) => ...)`。

- **MUST 测试命名 = "what should happen when ..."。**
  - Why: 测试名是给**未来的人**看的（包括 CI 报告）。"test_add" 没意义。
  - How: `it('should return 0 when empty array', ...)` 而不是 `it('test_sum_empty', ...)`。

- **MUST 断言公开契约。**
  - Why: 实现会变，契约是稳的。测实现 = 每次重构测试都红。
  - How: 只断言 function 的输入/输出 + 对 DB/外部的可观察效应。不访问 `._private`、`.internal`。

- **MUST 覆盖率阈值是"结果"不是"目标"。**
  - Why: 追数字会诱导写无效测试。
  - How: 阈值在 harness 里硬锁（默认 80% lines），但**关键模块**单独 100%。未达标的模块显式说明为什么。

- **MUST 并发调用无依赖工具。**
  - Why: 速度。Step 2 探索并行执行。
  - How: Read 被测代码 + Grep 现有测试 + Read 测试配置 放在同一条消息里发。

### NEVER

- **NEVER mock 被测单元自己的依赖。**
  - Why: mock 了 = 你在测 mock 不是测真实行为。重构 mock 也要一起改，维护地狱。
  - How: 只有**外部第三方**（Stripe、OpenAI API、外部 SMTP）才 mock。内部 service / util / repo 不 mock。

- **NEVER mock 数据库。**
  - Why: CLAUDE.md 全局反面教训：「integration tests must hit a real database, not mocks. Prior incident where mock/prod divergence masked a broken migration」。
  - How: 用 testcontainers / sqlite 内存模式 / docker-compose 起真实 DB。

- **NEVER 测试引用实现细节。**
  - Why: 实现细节变动时测试误报红色——噪音。
  - How: 不 `spyOn` 私有方法。不测 "this class has a _cache member"。测行为。

- **NEVER 单纯追覆盖率数字。**
  - Why: 覆盖率 100% 的代码照样有 bug（弱断言 / 没测 error path）。
  - How: 报告里**未覆盖区**要列出 + 说原因（"这段是 log 格式化，手测过"、"这段是 migration，集成测试覆盖"）。

- **NEVER `sleep(N)` 等异步。**
  - Why: flaky。CI 上有时快有时慢，测试会"偶尔"红。
  - How: 用条件轮询（`waitFor` / `eventually`）；组合 `condition-based-waiting` skill。

- **NEVER 写"smoke test"当完整测试。**
  - Why: `expect(result).toBeDefined()` 不叫测试，叫"看代码没崩"。
  - How: 每个 assert 必须是**具体的**期望值 / 关系 / 副作用。

- **NEVER 无断言的测试。**
  - Why: 测试不报红 = 没价值。
  - How: 每个 `it` / `test` 至少一个 `expect` / `assert`。只测 "not throw" 的要明确说明为什么这就是契约。

- **NEVER 测试互相依赖。**
  - Why: 顺序一乱就红，随机执行顺序会发现。
  - How: 每个测试自己 setup + teardown。`beforeEach` 重置全局状态。

### CRITICAL（skill 特有）

- **CRITICAL 集成测试必须跑真实 DB / 真实 API contract。**
  - Why: 呼应 CLAUDE.md 全局 feedback memory："mock 测试通过但 prod migration 挂"的事故。
  - How: 用 docker-compose 起 MongoDB / Postgres，跑完拆。API contract 用 Pact / schema 校验。

- **CRITICAL Mutation test 抓不住 = 测试必须加强。**
  - Why: mutation testing 是"反向验证"的自动化——证明测试能红。没抓住 = 弱断言。
  - How: `stryker run --mutate "src/core/**"`；未 killed 的 mutation 要么加测试要么标"活着但可接受"并说明理由。

**其余 CRITICAL（MongoDB 测试隔离 / Opus subagent / 失败升级）见 `_shared/kevin-personal-constraints.md`。**
